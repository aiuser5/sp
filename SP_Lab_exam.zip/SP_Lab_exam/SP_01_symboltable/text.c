#include <stdio.h>
int main() {   
    int a,r,q;
    int arr[30];
    float b;
    char c[10];
    char ch;
    double db;
    printf("Enter an integer: ");  
    scanf("%d", &a);
    printf("You entered: %d", a);
    printf("output is %d", a);
    return 0;
}

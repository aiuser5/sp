// #include<stdio.h>

void main()
{
    extern int no2;
    extern int no2;
    float f1;
    float f2;
    int d1;
    int d2;
    char e;
}
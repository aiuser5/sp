void main()
{
    extern int d1;
    extern int d2;
    extern float f1;
    extern float f2;
    extern char e;

    int no1;
    int no2;
    
}